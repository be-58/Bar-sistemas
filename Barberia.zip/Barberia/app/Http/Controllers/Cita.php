<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Cita extends Controller
{
    //
}
