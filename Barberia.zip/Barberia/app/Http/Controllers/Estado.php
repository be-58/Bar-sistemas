<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Estado extends Controller
{
    //
}
