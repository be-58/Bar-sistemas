<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Usuario extends Model
{
    protected $table = 'usuarios';

    protected $primaryKey = 'ID_Usuario';

    protected $fillable = [
        'nombre', 'correo', 'telefono', 'rol', 'contrasena', 'Estado',
        'fecha_creacion', 'rol_caducidad'
    ];

    public function estado()
    {
        return $this->belongsTo(Estado::class, 'Estado');
    }

    public function barberias()
    {
        return $this->hasMany(Barberia::class, 'IDUsuario');
    }

    public function servicios()
    {
        return $this->hasMany(Servicio::class, 'IDUsuario');
    }

    public function agendas()
    {
        return $this->hasMany(Agenda::class, 'IDUsuario');
    }

    public function citas()
    {
        return $this->hasMany(Cita::class, 'IDUsuario');
    }
}
