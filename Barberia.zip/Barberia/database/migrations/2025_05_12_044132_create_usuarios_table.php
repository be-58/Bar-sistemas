<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('usuarios', function (Blueprint $table) {
             $table->id('ID_Usuario');
             $table->string('nombre');
             $table->string('correo')->unique();
             $table->string('telefono')->nullable();
             $table->string('rol');
             $table->string('contrasena');
             $table->unsignedBigInteger('Estado');
             $table->date('fecha_creacion');
             $table->date('rol_caducidad')->nullable();
             $table->timestamps();

            $table->foreign('Estado')->references('IDEstado')->on('estados');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('usuarios');
    }
};
