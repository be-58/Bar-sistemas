<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('citas', function (Blueprint $table) {
            $table->id('IDCita');
            $table->unsignedBigInteger('IDAgenda');
            $table->unsignedBigInteger('IDUsuario');
            $table->unsignedBigInteger('IDBarberia');
            $table->unsignedBigInteger('IDServicio');
            $table->date('fecha');
            $table->time('hora');
            $table->unsignedBigInteger('estado');
            $table->date('fecha_creacion');
            $table->date('fecha_caducidad')->nullable();
            $table->timestamps();

            $table->foreign('IDAgenda')->references('IDAgenda')->on('agenda');
            $table->foreign('IDUsuario')->references('ID_Usuario')->on('usuarios');
            $table->foreign('IDBarberia')->references('IDBarberia')->on('barberia');
            $table->foreign('IDServicio')->references('IDServicio')->on('servicio');
            $table->foreign('estado')->references('IDEstado')->on('estados');
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('citas');
    }
};
