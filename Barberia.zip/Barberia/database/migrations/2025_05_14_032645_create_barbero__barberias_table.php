<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('barbero__barberias', function (Blueprint $table) {
            $table->unsignedBigInteger('IDUsuario');
            $table->unsignedBigInteger('IDBarberia');
            $table->string('nombre');
            $table->timestamps();

            $table->primary(['IDUsuario', 'IDBarberia']);

            $table->foreign('IDUsuario')->references('ID_Usuario')->on('usuarios');
            $table->foreign('IDBarberia')->references('IDBarberia')->on('barberia'); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('barbero__barberias');
    }
};
