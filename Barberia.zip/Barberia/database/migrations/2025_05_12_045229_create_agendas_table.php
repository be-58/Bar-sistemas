<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('agendas', function (Blueprint $table) {
              $table->id('IDAgenda');
              $table->unsignedBigInteger('IDUsuario');
              $table->date('fecha');
              $table->time('HoraInicio');
              $table->time('HoraFin');
              $table->unsignedBigInteger('Estado');
              $table->timestamps();

              $table->foreign('IDUsuario')->references('ID_Usuario')->on('usuarios');
              $table->foreign('Estado')->references('IDEstado')->on('estados');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('agendas');
    }
};
