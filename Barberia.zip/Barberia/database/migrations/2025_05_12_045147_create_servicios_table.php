<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('servicios', function (Blueprint $table) {
            $table->id('IDServicio');
            $table->unsignedBigInteger('IDBarberia');
            $table->unsignedBigInteger('IDUsuario');
            $table->string('nombre');
            $table->text('descripcion')->nullable();
            $table->decimal('precio', 8, 2);
            $table->integer('duracionServicio');
            $table->date('fecha_creacion');
            $table->date('fecha_caducidad')->nullable();
            $table->unsignedBigInteger('Estado');
            $table->timestamps();

            $table->foreign('IDBarberia')->references('IDBarberia')->on('barberia');
            $table->foreign('IDUsuario')->references('ID_Usuario')->on('usuarios');
            $table->foreign('Estado')->references('IDEstado')->on('estados');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('servicios');
    }
};
